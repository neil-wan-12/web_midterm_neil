第一次開的話把undex.php裡最上面的php uncomment 掉，跑一次後再 comment 掉，以創建database 

放到xampp 的 htdocs 裡

然後到
localhost/midterm/index.php 就看的到了