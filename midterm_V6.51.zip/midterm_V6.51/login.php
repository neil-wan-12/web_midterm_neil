<?php
    session_start();

    include("connection.php");
    include("function.php");

    if($_SERVER['REQUEST_METHOD'] == "POST")
    {
        //something was posted
        $user_name =  $_POST['user_name'];
        $password =  $_POST['password'];

        if(!empty($user_name) && !empty($password) && !is_numeric($user_name))
        {
            //read from database
            $query = "select * from users where user_name = '$user_name'";
            
            $result = mysqli_query( $con,$query);

            if($result && mysqli_num_rows($result) > 0)
            {
                $user_data = mysqli_fetch_assoc($result);
                if($user_data['password'] === $password){
                    $_SESSION['user_id'] = $user_data['user_id']; //to let the function "login_check" know it isset = true 
                    $_SESSION['user_name'] = $user_data['user_name']; // Store the username
                    header('Location: index.php');
                    die;
                }
            }

            echo "wrong user_name or password";

        }else
        {
            echo "Please enter valid info";
        }

    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login</title>
    <style>
        #box{
            background: gray;
            margin: auto;
            width: 300px;
            padding: 20px;
        }

    </style>
</head>

<body>
    <div id="box">
        <form method="post">
            <h3>Login</h3>
            <!-- 登入區塊 -->
            <input type="text" name="user_name"><br><br>
            <input type="text" name="password"><br><br>

            <input type="submit" value="Login"><br><br>

            <!-- 註冊帳號 -->
            <a href="signup.php">SignUp</a>


        </form>
    </div>
</body>
</html>